"""Build this round's portable evidence; run from repository root. No Git mutation."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

root=Path.cwd()
work=root/'outputs/m03/r09_final'
advanced=root/'lane_detection/advanced'
baseline=work/'baseline'
report_path=root/'lane_detection/M03_R09_FINAL_REPORT.md'
results_path=root/'lane_detection/M03_R09_FINAL_RESULTS.json'
bundle_path=root/'lane_detection/M03_R09_REVIEW_BUNDLE.zip'


def read(name):
    return json.loads((work/(name+'.json')).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def suite(name):
    content=(work/name).read_text(errors='replace')
    count=int(re.search(r'^Ran (\d+) tests?',content,re.M)[1])
    assert re.search(r'^OK\s*$',content,re.M),name
    assert not re.search(r'^FAILED',content,re.M),name
    return dict(tests=count,passed=count,failed=0,skipped=0,log=name)


before=read('performance_before')
after_on=read('performance_after_on')
after=read('performance_after_default')
assert all(a['image_sha256']==b['image_sha256']==c['image_sha256']
           for a,b,c in zip(before['records'],after_on['records'],after['records']))
assert len(before['records'])==len(after_on['records'])==len(after['records'])==128
source_changes=[]
diff=[]
for path in sorted(advanced.iterdir()):
    if not path.is_file():
        continue
    original=baseline/path.name
    current=path.read_bytes()
    previous=original.read_bytes() if original.exists() else b''
    if original.exists() and previous==current:
        continue
    kind='test' if path.name.startswith('test_') else 'documentation' if path.suffix=='.md' else 'production' if path.name in ('config.py','extraction.py','fitting.py','models.py','pipeline.py') else 'evaluation'
    source_changes.append(dict(path=path.relative_to(root).as_posix(),kind=kind,
        status='modified' if original.exists() else 'added',sha256=digest(current),
        entry_sha256=digest(previous) if original.exists() else None))
    diff.extend(difflib.unified_diff(previous.decode('utf8').splitlines(True),current.decode('utf8').splitlines(True),
        fromfile='entry/'+path.name if original.exists() else '/dev/null',tofile='current/'+path.name))
(work/'source.diff').write_text(''.join(diff),encoding='utf8')
tests={name:suite(log) for name,log in (
    ('M01','m01_tests.txt'),('M02','m02_tests.txt'),('M03','default_m03.txt'),
    ('full_discovery','full_tests.txt'),('video_assets','video_tests.txt'))}
reconstruction=read('reconstruction') if (work/'reconstruction.json').exists() else None
summary=dict(
    verdict='CONDITIONAL PASS; unconditional original R-09 8/8 acceptance remains unmet',
    head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    no_git_mutations=True,baseline='entry 107-test uncommitted M03 engine',
    changed_source_files=source_changes,
    delivery_artifacts=['lane_detection/M03_R09_FINAL_REPORT.md','lane_detection/M03_R09_FINAL_RESULTS.json',
        'lane_detection/M03_R09_REVIEW_HANDOFF.md','lane_detection/M03_R09_REVIEW_BUNDLE.zip',
        'lane_detection/M03_R09_REVIEW_BUNDLE.sha256'],
    preexisting_tracked_modifications_preserved=['.gitignore','README.md','lane_detection/README.md'],
    tests=tests,reconstruction=reconstruction,protocol_identity=read('protocol_identity'),
    association_equivalence=read('association_equivalence'),cap_mutation=read('cap_mutation'),
    performance_before=before,performance_after_hough_on=after_on,performance_after_default=after,
    breadth_before=read('breadth_before'),ablation_on=read('ablation_on'),ablation_off=read('ablation_off'),
    stress=read('stress'),memory=read('memory'),semantics_before=read('semantics_before'),
    semantics_after=read('semantics_after'),reviewer_before=read('reviewer_before'),reviewer_after=read('reviewer_after'),
    p1=read('p1'),transitions=read('transitions'),video=read('video/run_summary'),
    limitations=['Original 320x240 60-fragment recall is 6/8 scoped-correct, 5/8 original midpoint pass; 640x480 is 7/8.',
        'Remaining companion/branch ambiguity is preserved, not pruned to force recall.',
        'Semantic wall/glare false-valid remains 8/15 in separate adversarial negatives.',
        'Four original R08 boundary-error audits exceed 2.5 px before and after; maximum 2.7452 px.',
        'Desktop scheduling maxima vary; operation caps do not promise a wall-clock deadline.',
        'Synthetic and simulated-attestation evidence does not validate physical calibration, track accuracy, Pi or thermal performance.'])
results_path.write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n',encoding='utf8')

text=report_path.read_text().split('\n<!-- GENERATED EVIDENCE -->')[0]
text+='\n<!-- GENERATED EVIDENCE -->\n\n## Final measured performance\n\n'
text+='Intel Core i5-13450HX, Windows 11 build 26300, Python 3.14.10, OpenCV 5.0.0, NumPy 2.5.4; one OpenCV thread. '
text+='Eight seeded images/group, two warmups and 20 timed repeats per image (160 samples/group). Timings exclude acquisition, drawing, encoding and memory tracing. '
text+='The three runs used identical image hashes. Hough-on compares like-for-like; default-off measures the final configuration. '
text+='Background OS scheduling remains uncontrolled. The 320 clean maximum increased despite lower median/p95; no hard worst-case deadline is claimed.\n\n'
text+='Latency cells are **median / p95 / max ms**. Recall is scoped-correct valid scenes out of eight.\n\n'
text+='| Size / case | Entry, Hough on | Corrected, Hough on | Corrected default off | Recall entry→corrected | Budget events entry→corrected |\n|---|---|---|---|---|---|\n'
for a,b,c in zip(before['groups'],after_on['groups'],after['groups']):
    label=f"{320*a['scale']}×{240*a['scale']} / {a['kind']} {a['count']}"
    def latency(g):
        return ' / '.join(f"{g[k]:.2f}" for k in ('median_ms','p95_ms','max_ms'))
    text+=f"| {label} | {latency(a)} | {latency(b)} | {latency(c)} | {a['correct_valid']}→{c['correct_valid']} | {a['budget_events']}→{c['budget_events']} |\n"
text+='\nAll requested straight-scene groups have zero incorrect-valid outputs before/after. '
text+='At 60 fragments, maximum counted comparisons are 4,000→601 (320) and 4,000→634 (640); peak active tracks remain 19 and 20 respectively. '
text+='Comparison counts have different accounting semantics: entry counts every active-track/run pair; corrected counts only spatially eligible pairs. '
text+='The 240-scene increased stress matrix has zero incorrect-valid results and 76 conservative capacity exits; peak active tracks 48, maximum scored comparisons 3,562. '
text+='All capacity exits expose uncertainty, not partial selected geometry.\n\n'
text+='### Memory\n\nThe separate existing author 200-speck fixture uses ten warmups plus 100 new frames at each resolution. Python tracemalloc excludes native OpenCV allocations; process working-set data are also saved. RSS peaks are cumulative for the process.\n\n'
text+='| Mode / size | Python peak bytes | Live growth bytes | Process peak working set bytes |\n|---|---:|---:|---:|\n'
for name in ('before','after_default'):
    for row in summary['memory'][name]:
        text+=f"| {name} / {row['size'][0]}×{row['size'][1]} | {row['python_peak_bytes']} | {row['python_live_growth_bytes']} | {row['process_memory_after']['PeakWorkingSet64']} |\n"
text+='\nNo frame-accumulating track store was observed. Bounds and repeated-frame tests provide stronger evidence than interpreting a short memory trend as a proof of no possible leak.\n\n'
text+='## Final regression counts\n\n| Suite | Passed | Failed | Skipped |\n|---|---:|---:|---:|\n'
for name,row in tests.items():
    text+=f"| {name} | {row['passed']} | 0 | 0 |\n"
if reconstruction:
    text+=f"| Fresh HEAD plus packaged overlay | {reconstruction['tests']} | 0 | 0 |\n"
text+='\nFourteen new test methods supplement the entry 107 M03 tests; original assertions are retained. '
text+='CLI reaches EOF at 590 observations, source IDs 1..590, no skipped source frames; profile remains SYNTHETIC / METRIC_UNVERIFIED. '
text+='Negative-input tests intentionally emit camera/decode diagnostics; suite status comes from unittest summaries.\n\n'
text+='Additional executed commands:\n\n```powershell\n'
text+='python -m unittest lane_detection.advanced.test_r09_spatial -v\n'
text+='python -m unittest lane_detection.advanced.test_final_support lane_detection.advanced.test_final_interfaces -v\n'
text+='python -m unittest lane_detection.advanced.test_final_quality -v\n'
text+='python outputs/m03/r09_final/association_equivalence.py\n'
text+='python outputs/m03/r09_final/verify_cap_mutation.py\n'
text+='python -m lane_detection.advanced --source videos/test.mp4 --profile calibration/test_video_metric_profile.json --headless --output outputs/m03/r09_final/video\n'
text+='python outputs/m03/r09_final/finalize_evidence.py\n```\n\n'
text+='Memory was measured by `availability_evaluation.memory_report(Path("outputs/m03/r09_final/baseline"), 100)` and `memory_report(None, 100)` in a separate one-thread Python process. '
text+='All intermediate trial logs, including failed new-fixture assumptions and the corrected isolated-bias experiment, are retained in the bundle.\n\n'
text+='## Changed-file manifest for this round\n\nCompare against the entry snapshot, not Git HEAD, which has no M03 package.\n\n'
text+='| File | Kind | Change |\n|---|---|---|\n'
for row in source_changes:
    text+=f"| `{row['path']}` | {row['kind']} | {row['status']} |\n"
text+='\nDelivery artifacts: `M03_R09_FINAL_REPORT.md`, `M03_R09_FINAL_RESULTS.json`, `M03_R09_REVIEW_HANDOFF.md`, `M03_R09_REVIEW_BUNDLE.zip`, `M03_R09_REVIEW_BUNDLE.sha256`, all under `lane_detection/`. '
text+='They are not Git-ignored. `.gitignore`, root README and lane_detection README already differed at entry and were preserved. '
text+='Other M03 files were already untracked and remain present. No M01/M02 production or legacy detector file changed. '
text+='The archive includes the whole current M03 overlay, entry snapshot, `source.diff`, evidence and a per-member SHA256 manifest; its sidecar hashes the archive itself.\n\n'
text+='## Remaining risks and approval boundary\n\n'
text+='Software: original unconditional 8/8 recall is unmet; conservative ambiguity causes refusals. Constant-width non-road materials remain semantic false positives. '
text+='Confidence is heuristic, and four original transition cases exceed a 2.5 px boundary audit. Low-level polynomial evaluation remains unrestricted for backward compatibility; consumers must respect domains or use the new guarded query. '
text+='Measured desktop maxima vary with scheduling.\n\n'
text+='Missing physical evidence: vehicle reference/calibration provenance, labelled real-track recognition and score calibration, Pi 5 CPU/thermal latency and physical vehicle behavior. '
text+='These cannot be established by synthetic fixtures or desktop execution. No newly introduced P0/P1 was identified. '
text+='R-09 budget correction is ready for independent inspection, but unconditional M03 software approval should not be asserted until the documented recall exception is accepted or resolved.\n'
report_path.write_text(text,encoding='utf8')

# Include the complete overlay needed on HEAD, not only this round's diff.
overlay=[p for p in advanced.iterdir() if p.is_file()]
overlay += [p for p in (root/'lane_detection').glob('M03*') if p.suffix in ('.md','.json')]
overlay += [root/'.gitignore',root/'README.md',root/'lane_detection/README.md']
members={}
for path in overlay:
    members['overlay/'+path.relative_to(root).as_posix()]=path.read_bytes()
for path in sorted(baseline.iterdir()):
    if path.is_file():
        members['baseline/'+path.name]=path.read_bytes()
for path in sorted(work.iterdir()):
    if path.is_file():
        members['evidence/'+path.name]=path.read_bytes()
for path in (work/'video').iterdir():
    if path.is_file() and path.suffix in ('.json','.jsonl'):
        members['evidence/video/'+path.name]=path.read_bytes()
manifest=dict(head=summary['head'],baseline='Entry 107-test snapshot',
    files=[dict(path=name,bytes=len(data),sha256=digest(data)) for name,data in sorted(members.items())])
with zipfile.ZipFile(bundle_path,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,data in sorted(members.items()):
        archive.writestr(name,data)
    archive.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(bundle_path) as archive:
    actual=json.loads(archive.read('manifest.json'))
    for row in actual['files']:
        assert digest(archive.read(row['path']))==row['sha256'],row['path']
sidecar=bundle_path.with_suffix('.sha256')
sidecar.write_text(digest(bundle_path.read_bytes())+'  '+bundle_path.name+'\n')
print(json.dumps(dict(source_changes=len(source_changes),members=len(members),bundle_bytes=bundle_path.stat().st_size,
    sha256=digest(bundle_path.read_bytes()),all_hashes_verified=True,
    reconstruction={k:v for k,v in reconstruction.items() if k!='overlay_python_hashes'} if reconstruction else None),indent=2))
