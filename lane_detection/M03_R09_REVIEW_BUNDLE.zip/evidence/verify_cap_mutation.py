"""Prove the in-grid above-cap regression fails when its numeric cap is removed."""
import inspect
import json
from pathlib import Path
import sys
import textwrap
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from lane_detection.advanced import pipeline
from lane_detection.advanced.test_final_support import SupportReferenceTests

source=textwrap.dedent(inspect.getsource(pipeline.LaneDetector._process))
needle='and extension <= self.config.max_reference_extension_px'
assert source.count(needle)==1
namespace=dict(pipeline.__dict__)
exec(source.replace(needle,'and True'),namespace)
result=unittest.TestResult()
with patch.object(pipeline.LaneDetector,'_process',namespace['_process']):
    SupportReferenceTests('test_reference_cap_at_below_and_above_six_pixels').run(result)
report=dict(mutation='Removed numeric reference-extension cap in an isolated in-memory method patch',
    tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    killed=len(result.failures)==1 and not result.errors,
    failure_details=[failure for _,failure in result.failures])
assert report['killed'],report
Path('outputs/m03/r09_final/cap_mutation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
