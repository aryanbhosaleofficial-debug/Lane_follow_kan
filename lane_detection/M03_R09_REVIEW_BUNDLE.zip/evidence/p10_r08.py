"""R-08: straight-to-curve transitions, independent exact geometry. PREV (reviewed last time) vs NEW (current)."""
import sys, collections, math
from rv import *
PREV = "prev_adv"
W = 130.0; CX = 135.0

def tu(v, o, R, vt, d):
    """True u of the boundary with straight offset o (u0=CX+o) for rows v. d=+1 curves toward +u going far (up)."""
    v = np.asarray(v, float)
    r = R - d * o
    cu = CX + d * R
    dv = np.minimum(vt - v, 0) * 0 + np.maximum(vt - v, 0)           # rows above (smaller v than) transition
    inside = np.sqrt(np.maximum(r * r - dv * dv, 0))
    return np.where(v >= vt, CX + o, cu - d * inside)

def centre(v, R, vt, d):
    return tu(v, 0.0, R, vt, d)

def scene(R, vt, d, dashed=False, v0=6, v1=233, miss=None, stub=None):
    img = blank()
    rows = np.arange(v0, v1 + 1, .2)
    for o in (-W / 2, W / 2):
        if miss is not None and o == miss: continue
        u = tu(rows, o, R, vt, d)
        ok = np.ones(len(rows), bool)
        if stub is not None:
            ok &= rows >= vt - stub              # only `stub` rows of the arc are visible
        # arc must exist geometrically
        ok &= (np.maximum(vt - rows, 0) < (R - d * o))
        pts = np.column_stack((u, rows))
        if dashed:
            ok &= ((rows - v0) % 54) < 30
        cuts = np.flatnonzero(np.diff(np.r_[False, ok, False].astype(np.int8)))
        for s, e in zip(cuts[::2], cuts[1::2]):
            if e - s >= 2:
                cv2.polylines(img, [np.rint(pts[s:e]).astype(np.int32)], False, (255, 255, 255), 5)
    return img

def evaluate(pkg, img, R, vt, d):
    f = frame(pkg, img)
    o = detector(pkg, max_frame_age_s=None).process(f)
    out = dict(validity=o.validity, limited=getattr(o, "limited_support", False), reasons=[r for r in o.reason_codes if r != "pixel_geometry_only"])
    sp = o.selected_pair
    if not sp:
        return out
    by = {b.candidate_id: b for b in o.boundaries}
    errs = []
    for bid in (sp.left_id, sp.right_id):
        p = by[bid].polynomial
        v = np.linspace(p.v_min, p.v_max, 120)
        mid = float(p.evaluate((p.v_min + p.v_max) / 2))
        off = -W / 2 if mid < CX + (0 if d == 0 else 0) and abs(mid - (CX - W / 2)) < abs(mid - (CX + W / 2)) else W / 2
        # choose nearest true boundary (offset) by comparing at the near end
        cand = min((-W / 2, W / 2), key=lambda oo: abs(float(p.evaluate(p.v_max)) - (CX + oo)))
        errs.append(float(np.max(np.abs(p.evaluate(v) - tu(v, cand, R, vt, d)))))
    c = sp.centreline
    v = np.linspace(c.v_min, c.v_max, 120)
    cerr = float(np.max(np.abs(c.evaluate(v) - centre(v, R, vt, d))))
    nan_out = bool(np.isnan(c.evaluate([c.v_min - 2, c.v_max + 2])).all()) if hasattr(c, "allow_extrapolation") else None
    out.update(bound_err=max(errs), centre_err=cerr, v_min=float(c.v_min), v_max=float(c.v_max), nan_out=nan_out,
               into_arc=float(max(0.0, vt - c.v_min)), width=float(sp.width_mean_px),
               usable=getattr(o, "usable_support_v_px", None), unsup=getattr(o, "unsupported_far_intervals", None),
               status=getattr(o, "support_status", None), conf=o.confidence)
    return out

if __name__ == "__main__":
    Rs = (120, 220, 400, 800, 2000); vts = (40, 70, 100, 130, 160, 190, 215)
    for dashed in (False, True):
        print(f"\n##### {'DASHED' if dashed else 'SOLID'} boundaries; truth = exact tangent-continuous concentric arcs; centre-line/boundary error over the REPORTED domain")
        agg = {PREV: collections.Counter(), NEW: collections.Counter()}
        worst = {PREV: 0.0, NEW: 0.0}; worst_into = {PREV: 0.0, NEW: 0.0}; nan_bad = collections.Counter(); unflagged_bad = collections.Counter()
        rows_print = []
        for R in Rs:
            for vt in vts:
                for d in (+1, -1):
                    img = scene(R, vt, d, dashed)
                    res = {pkg: evaluate(pkg, img, R, vt, d) for pkg in (PREV, NEW)}
                    for pkg, r in res.items():
                        agg[pkg][r["validity"]] += 1
                        if r["validity"] == "valid":
                            agg[pkg]["limited" if r["limited"] else "full"] += 1
                            worst[pkg] = max(worst[pkg], r["centre_err"], r["bound_err"])
                            worst_into[pkg] = max(worst_into[pkg], r["into_arc"])
                            if pkg == NEW and r["limited"] and r["nan_out"] is not True: nan_bad["limited-not-NaN-outside"] += 1
                            if pkg == NEW and r["centre_err"] > 2.5: unflagged_bad["centre_err>2.5"] += 1
                            if pkg == NEW and r["bound_err"] > 2.5: unflagged_bad["bound_err>2.5"] += 1
                    rows_print.append((R, vt, d, res))
        for pkg, name in ((PREV, "PREV"), (NEW, "NEW ")):
            print(f"  {name}: {dict(agg[pkg])}  worst valid-domain error {worst[pkg]:.2f}px  max rows-into-arc in domain {worst_into[pkg]:.0f}")
        print("  NEW anomalies:", dict(nan_bad), dict(unflagged_bad))
        if dashed is False:
            print(f"  {'R':>5s} {'vt':>4s} {'dir':>3s} | {'PREV':>10s} | {'NEW':>10s} ltd  domain(v)     cerr  berr  intoArc  NaNout  reasons")
            for R, vt, d, res in rows_print:
                if d != 1: continue
                p, n = res[PREV], res[NEW]
                if n["validity"] == "valid":
                    extra = f"{'Y' if n['limited'] else 'n'}   {n['v_min']:5.0f}-{n['v_max']:3.0f}  {n['centre_err']:5.2f} {n['bound_err']:5.2f} {n['into_arc']:7.0f}  {str(n['nan_out']):6s}"
                else:
                    extra = f"-   {'':11s} {'':5s} {'':5s} {'':7s} {'':6s}  {n['reasons'][:3]}"
                print(f"  {R:5d} {vt:4d} {d:3d} | {p['validity']:>10s} | {n['validity']:>10s} {extra}")
