import importlib,json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from dataclasses import replace
import cv2,numpy as np
from lane_detection.advanced.availability_evaluation import engine_at
from lane_detection.advanced.availability_cases import availability_frame
from lane_detection.advanced.r09_cases import review_case
cv2.setNumThreads(1)
p=Path('outputs/m03/r09_final')
base=engine_at(p/'baseline');new=engine_at(None)
engines=[base,new];mods=[(importlib.import_module(e.__name__+'.preprocessing'),importlib.import_module(e.__name__+'.extraction')) for e in engines]
checked=0;failures=[]
for scale in (1,2):
 for geometry in ('straight','curve','dashed','multi','companion','no_lane','noise'):
  for kind,count in [('fragments',n) for n in (0,40,60,80,100)]+[('specks',n) for n in (100,200,300)]:
   for seed in range(8):
    f=availability_frame(review_case(kind,count,seed,scale,geometry),scale)
    outputs=[]
    for engine,(pre,ex) in zip(engines,mods):
     cfg=engine.LaneConfig.for_bev(f.bev,(.18,1.04),max_frame_age_s=None,use_hough=False,max_association_comparisons=100000)
     outputs.append(ex.extract(pre.Preprocessor(cfg).process(f),cfg))
    a,b=outputs
    equal=(a.overloaded==b.overloaded and a.branch_detected==b.branch_detected and len(a.tracks)==len(b.tracks) and all(np.array_equal(x,y) for x,y in zip(a.tracks,b.tracks)) and all(np.array_equal(x,y) for x,y in zip(a.track_widths,b.track_widths)))
    if not equal:failures.append((scale,geometry,kind,count,seed))
    checked+=1
report=dict(scenes=checked,identical=checked-len(failures),failures=failures,description='Entry brute-force extraction vs spatial extraction, same high diagnostic budget, Hough off; exact track points, widths, branch and overload flags.')
(p/'association_equivalence.json').write_text(json.dumps(report,indent=2)+'\n')
print(report)
assert not failures
