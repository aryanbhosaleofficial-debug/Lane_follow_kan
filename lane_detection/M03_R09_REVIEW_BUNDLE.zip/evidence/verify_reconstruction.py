"""Verify a fresh HEAD plus packaged overlay without modifying the working tree."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zipfile

root=Path.cwd()
work=root/'outputs/m03/r09_final'
bundle=root/'lane_detection/M03_R09_REVIEW_BUNDLE.zip'
target=Path(tempfile.mkdtemp(prefix='reconstruction_',dir=work))
head=subprocess.check_output(['git','archive','--format=zip','HEAD'])
with zipfile.ZipFile(io.BytesIO(head)) as z:
    for name in z.namelist():
        assert (target/name).resolve().is_relative_to(target.resolve())
    z.extractall(target)
python_hashes={}
with zipfile.ZipFile(bundle) as z:
    manifest=json.loads(z.read('manifest.json'))
    for row in manifest['files']:
        data=z.read(row['path'])
        assert hashlib.sha256(data).hexdigest()==row['sha256']
        if not row['path'].startswith('overlay/'):
            continue
        name=row['path'][len('overlay/'):]
        path=target/name
        assert path.resolve().is_relative_to(target.resolve())
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
        if name.endswith('.py'):
            python_hashes[name]=row['sha256']
probe=subprocess.check_output([sys.executable,'-c',
    'from pathlib import Path; import lane_detection.advanced as m; p=Path(m.__file__).resolve(); assert p.is_relative_to(Path.cwd()); print(p)'],
    cwd=target,text=True).strip()
log=work/'reconstruction_tests.txt'
with log.open('w',encoding='utf8') as f:
    result=subprocess.run([sys.executable,'-m','unittest','discover','-v'],cwd=target,stdout=f,stderr=subprocess.STDOUT)
text=log.read_text()
assert result.returncode==0,text[-3000:]
assert re.search(r'^OK\s*$',text,re.M)
count=int(re.search(r'^Ran (\d+) tests',text,re.M)[1])
assert count==454,count
report=dict(directory=str(target),imported_module=probe,command='python -m unittest discover -v',
    tests=count,passed=count,failed=0,skipped=0,returncode=result.returncode,
    overlay_python_hashes=python_hashes,verified_all_bundle_member_hashes=True)
(work/'reconstruction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='overlay_python_hashes'},indent=2))
