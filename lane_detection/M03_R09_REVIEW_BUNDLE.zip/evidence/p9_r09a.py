"""R-09: reproduce the previous protocol (my own generators, seeds 0..7) on OLD(54 tests), PREV(85 tests, reviewed last time), NEW (current)."""
import collections, time, sys
from rv import *
from lane_detection.advanced.synthetic import scene

PREV = "prev_adv"
VERS = (("OLD", OLD), ("PREV", PREV), ("NEW", NEW))

def clean():
    return scene(((0, 0, 70), (0, 0, 200)))   # known lane 70/200

def frags(img, n, seed):
    rng = np.random.default_rng(seed)
    for _ in range(n):
        u, v = rng.integers([5, 5], [307, 222])
        cv2.line(img, (int(u), int(v)), (int(u + rng.integers(-3, 4)), int(v + rng.integers(4, 16))), (230, 230, 230), 2)
    return img

def specks(img, n, seed):
    rng = np.random.default_rng(seed)
    for _ in range(n):
        u, v = rng.integers([5, 5], [307, 233])
        cv2.circle(img, (int(u), int(v)), int(rng.integers(1, 3)), (240, 240, 240), -1)
    return img

def check(o):
    sp = o.selected_pair
    if not sp: return None
    by = {b.candidate_id: b for b in o.boundaries}
    return abs(float(by[sp.left_id].polynomial.evaluate(120)) - 70) < 2 and abs(float(by[sp.right_id].polynomial.evaluate(120)) - 200) < 2

def make_det(pkg):
    return detector(pkg) if pkg == OLD else detector(pkg, max_frame_age_s=None)

SEEDS = range(8)
for kind, fn, dens in (("short fragments (2px x 4-16 rows)", frags, (0, 20, 40, 60, 80, 100, 150, 200, 300, 400)),
                       ("round specks r=1-2", specks, (0, 50, 100, 200, 300, 500, 800, 1200))):
    print("##", kind, "- lane 70/200 clean and fully visible; 8 seeds each; cell = correct-valid / wrong-valid / median ms / budget-exhausted")
    print(f"{'n':>5s} | " + " | ".join(f"{name:>26s}" for name, _ in VERS))
    for n in dens:
        cells = []
        for name, pkg in VERS:
            good = wrong = over = 0; ts = []
            for seed in SEEDS:
                img = fn(clean(), n, seed)
                d = make_det(pkg); f = frame(pkg, img)
                t = time.perf_counter(); o = d.process(f); ts.append((time.perf_counter() - t) * 1e3)
                if o.valid:
                    c = check(o); good += (c is True); wrong += (c is False)
                over += ("processing_budget_exceeded" in o.reason_codes)
            cells.append(f"{good}/8 ok {wrong} wrong {np.median(ts):5.1f}ms ov{over}")
        print(f"{n:5d} | " + " | ".join(f"{c:>26s}" for c in cells))
    print()
