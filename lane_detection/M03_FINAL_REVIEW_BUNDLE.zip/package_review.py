"""Create a portable review overlay without changing Git or the saved baseline."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root=Path(__file__).resolve().parents[3]
work=root/'outputs/m03/final_correction'
base=work/'baseline'
current=root/'lane_detection/advanced'
sha=lambda data:hashlib.sha256(data).hexdigest()
baseline_hashes=json.loads((base/'hashes.json').read_text())
assert all(sha((base/name).read_bytes())==digest for name,digest in baseline_hashes.items())
files={}
for path in sorted(current.iterdir()):
    if path.is_file():
        files['overlay/'+path.relative_to(root).as_posix()]=path.read_bytes()
for path in sorted(base.iterdir()):
    if path.is_file():
        files['baseline/'+path.name]=path.read_bytes()
changes={}
diff=[]
for path in sorted(current.iterdir()):
    if not path.is_file():
        continue
    old=base/path.name
    before=old.read_text(encoding='utf8').splitlines(True) if old.exists() else []
    after=path.read_text(encoding='utf8').splitlines(True)
    if before!=after:
        changes[path.relative_to(root).as_posix()]='modified' if old.exists() else 'added'
        diff.extend(difflib.unified_diff(before,after,fromfile='baseline/'+path.name,tofile=path.relative_to(root).as_posix()))
files['source.diff']=''.join(diff).encode('utf8')
raw={p.name:json.loads(p.read_text(encoding='utf8')) for p in sorted(work.glob('*.json'))}
metadata=dict(generated_utc=datetime.now(timezone.utc).isoformat(),
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    source_changes_from_initial_m03=changes,baseline_sha256=baseline_hashes,
    evidence=raw)
results=root/'lane_detection/M03_FINAL_RESULTS.json'
results.write_text(json.dumps(metadata,indent=2,allow_nan=False)+'\n',encoding='utf8')
for name in ('README.md','.gitignore','lane_detection/README.md'):
    files['overlay/'+name]=(root/name).read_bytes()
for path in (root/'lane_detection').iterdir():
    if path.is_file() and path.suffix in ('.md','.json'):
        files['overlay/'+path.relative_to(root).as_posix()]=path.read_bytes()
for path in work.glob('*.json'):
    files['evidence/'+path.name]=path.read_bytes()
for path in root.glob('m03*.log'):
    files['evidence/logs/'+path.name]=path.read_bytes()
files['package_review.py']=Path(__file__).read_bytes()
files['final_checks.py']=(work/'final_checks.py').read_bytes()
files['reconstruct_review.py']=(work/'reconstruct_review.py').read_bytes()
for path in work.glob('*.png'):
    files['evidence/'+path.name]=path.read_bytes()
video_summary=work/'video/run_summary.json'
if video_summary.exists():
    files['evidence/video_run_summary.json']=video_summary.read_bytes()
files['working_tree.txt']=subprocess.check_output(['git','status','--short','--ignored'],cwd=root)
files['tracked.diff']=subprocess.check_output(['git','diff'],cwd=root)
manifest={name:sha(data) for name,data in sorted(files.items())}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode('utf8')
archive=root/'lane_detection/M03_FINAL_REVIEW_BUNDLE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(files.items()):
        z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name))==digest for name,digest in manifest.items())
print(json.dumps(dict(archive=str(archive.relative_to(root)),bytes=archive.stat().st_size,
                     sha256=sha(archive.read_bytes()),manifest_entries=len(manifest),baseline_files=len(baseline_hashes))))
