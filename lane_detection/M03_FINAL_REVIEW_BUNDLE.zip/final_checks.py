"""Verify source/evidence consistency and generate a review contact sheet."""
import hashlib
import importlib
import json
from pathlib import Path
import re
import subprocess
import sys
import warnings

root=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(root))
import cv2
import numpy as np
from lane_detection.advanced import LaneDetector
from lane_detection.advanced.availability_cases import clutter_case,transition_case
from lane_detection.advanced.availability_evaluation import engine_at
from lane_detection.advanced.models import Polynomial
from lane_detection.advanced.synthetic import bev_fixture
from lane_detection.advanced.visualization import draw_observation

w=root/'outputs/m03/final_correction'
read=lambda name:json.loads((w/(name+'.json')).read_text())
before,after=read('final_before'),read('final_after')
assert [r['image_sha256'] for r in before['records']]==[r['image_sha256'] for r in after['records']]
primary=[r for r in after['records'] if r['count']]
assert len(primary)==32 and all(r['correct_valid'] and not r['budget_exhausted'] for r in primary)
assert not any(r['incorrect_valid'] for r in after['records'])
stress=read('final_stress')
assert not any(r['incorrect_valid'] for r in stress['records'])
tb,ta=read('transitions_before'),read('final_transitions')
assert [r['image_sha256'] for r in tb['cases']]==[r['image_sha256'] for r in ta['cases']]
assert ta['failed']==0 and ta['required']==ta['required_recovered']==60
assert all(g['passed']==g['count'] for g in read('final_p1')['summary'].values())
unmodified=subprocess.check_output(['git','diff','--','camera_input','camera_calibration','requirements.txt',
                    'lane_detection/lane_detection.py','lane_detection/ipm_transform.py'],cwd=root)
assert not unmodified
base=w/'baseline'
for name,digest in json.loads((base/'hashes.json').read_text()).items():
    assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest
old=engine_at(base)
old_visualization=importlib.import_module(old.__name__+'.visualization')
try:
    with warnings.catch_warnings():
        warnings.simplefilter('error',RuntimeWarning)
        # The preserved old drawing loop oversteps a fractional limited domain.
        old_visualization._curve(np.zeros((240,320,3),np.uint8),
            Polynomial((0,0,100),120.25,230.0,False),(0,255,0),((120.25,230.0),))
except RuntimeWarning:
    overlay_baseline_reproduced=True
else:
    overlay_baseline_reproduced=False
assert overlay_baseline_reproduced
images=[clutter_case('fragments',0,0),clutter_case('fragments',60,0),transition_case(220,130)]
glare=np.full((240,320,3),35,np.uint8)
for v in range(240):
    half=int(round(2+7*v/239))
    for u in (70,200):
        glare[v,u-half:u+half+1]=255
images.append(glare)
views=[]
for image in images:
    detector=LaneDetector()
    result=detector.process(bev_fixture(image),debug=True)
    views.append(draw_observation(image,result,detector.last_debug))
sheet=np.vstack((np.hstack(views[:2]),np.hstack(views[2:])))
assert cv2.imwrite(str(w/'final_contact_sheet.png'),sheet)
tests={}
commands={
    'm01':'python -m unittest discover -s camera_input -t . -v',
    'm02':'python -m unittest discover -s camera_calibration -t . -v',
    'm03':'python -m unittest discover -s lane_detection/advanced -t . -v',
    'full':'python -m unittest discover -v',
    'video_assets':'python -m unittest camera_calibration.video_asset_tests -v'}
for name,command in commands.items():
    text=(root/('m03_final_'+name+'.log')).read_text()
    counts=re.findall(r'^Ran (\d+) tests in ([\d.]+)s$',text,re.M)
    assert len(counts)==1 and re.search(r'^OK$',text,re.M)
    tests[name]=dict(command=command,passed=int(counts[0][0]),failed=0,skipped=0,seconds=float(counts[0][1]))
summary=dict(tests=tests,unchanged_m01_m02_legacy=True,baseline_hashes_verified=35,
    identical_before_after_images=True,overlay_baseline_reproduced=True,
    primary_clutter_correct=32,primary_clutter_total=32,primary_clutter_incorrect_valid=0,
    transition_max_error_base_px=max(c['centre_error_base_px'] or 0 for c in ta['cases']),
    transition_baseline_over_tolerance=sum(c['valid'] and c['centre_error_base_px']>=2 for c in tb['cases']),
    transition_required_recovered=60,
    hardware=dict(cpu='13th Gen Intel Core i5-13450HX',cores=10,logical_processors=16,physical_ram_bytes=16849256448),
    video=json.loads((w/'video/run_summary.json').read_text()))
(w/'final_verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
