"""Deterministic robust polynomial fitting on normalized BEV row coordinates."""
from __future__ import annotations

import numpy as np

from .config import LaneConfig
from .models import Boundary, FitDiagnostics, Polynomial


def _robust_model(t: np.ndarray, u: np.ndarray, degree: int, threshold: float):
    design = np.vander(t, degree + 1)
    full_coef = np.linalg.lstsq(design, u, rcond=None)[0]
    full_residual = np.abs(design @ full_coef - u)
    if np.all(full_residual <= threshold):
        return full_coef, np.ones(len(t), dtype=bool), full_residual, float(np.linalg.cond(design))
    rng = np.random.default_rng(37 + degree)
    subsets = np.stack([rng.choice(len(t), degree + 1, replace=False) for _ in range(48)])
    matrices = design[subsets]
    usable = np.linalg.cond(matrices) <= 1e5
    # Batched tiny solves avoid dozens of Python/SVD/lstsq calls per boundary.
    candidates = np.linalg.solve(matrices[usable], u[subsets[usable]][..., None])[..., 0]
    candidates = np.vstack((full_coef, candidates))
    residuals = np.abs(design @ candidates.T - u[:, None])
    masks = residuals <= threshold
    counts = masks.sum(axis=0)
    best_index = np.lexsort((np.median(residuals, axis=0), -counts))[0]
    inliers = masks[:, best_index]
    for _ in range(4):
        if inliers.sum() < degree + 2:
            return None
        matrix = design[inliers]
        condition = float(np.linalg.cond(matrix))
        if condition > 1e5:
            return None
        coef = np.linalg.lstsq(matrix, u[inliers], rcond=None)[0]
        residual = np.abs(design @ coef - u)
        updated = residual <= threshold
        if np.array_equal(inliers, updated):
            break
        inliers = updated
    # Refit exactly the final inlier set; report the same model's diagnostics.
    if inliers.sum() < degree + 2:
        return None
    coef = np.linalg.lstsq(design[inliers], u[inliers], rcond=None)[0]
    residual = np.abs(design @ coef - u)
    return coef, inliers, residual, float(np.linalg.cond(design[inliers]))


def support_intervals(rows: np.ndarray, step: int) -> tuple[tuple[tuple[float, float], ...], tuple[tuple[float, float], ...]]:
    rows = np.unique(rows)
    breaks = np.flatnonzero(np.diff(rows) > step * 1.5)
    starts = np.r_[0, breaks + 1]
    ends = np.r_[breaks, len(rows) - 1]
    intervals = tuple((float(rows[a]), float(rows[b])) for a, b in zip(starts, ends))
    gaps = tuple((float(rows[k] + step / 2), float(rows[k + 1] - step / 2)) for k in breaks)
    return intervals, gaps


def fit_boundary(points: np.ndarray, config: LaneConfig, image_height: int, candidate_id: int) -> Boundary | None:
    """Return a supported fit or None. No endpoint extrapolation is performed.

    Random sampling has a fixed local seed and does not alter global RNG state.
    Row centres carry one vote each, so thick paint cannot dominate by pixel count.
    """
    p = np.asarray(points, dtype=float)
    if p.ndim != 2 or p.shape[1] != 2 or not np.isfinite(p).all():
        raise ValueError("fit points must be a finite Nx2 array of observed u,v")
    if len(p) < config.min_points:
        return None
    # Repeated rows are one observation, not independent support.
    rows = np.unique(p[:, 1])
    if len(rows) != len(p):
        p = np.array([(np.median(p[p[:, 1] == v, 0]), v) for v in rows])
    if len(p) < config.min_points:
        return None
    v, u = p[:, 1], p[:, 0]
    span = float(np.ptp(v))
    if span < config.min_span_px:
        return None
    origin = float((v.min() + v.max()) / 2)
    scale = span / 2
    t = (v - origin) / scale
    linear = _robust_model(t, u, 1, config.inlier_threshold_px)
    quadratic = (_robust_model(t, u, 2, config.inlier_threshold_px)
                 if span >= config.quadratic_min_span_px else None)
    model, degree = linear, 1
    if quadratic is not None:
        if linear is None or (quadratic[1].sum() > linear[1].sum() + max(2, len(p) * .05)
                             or np.median(linear[2]) - np.median(quadratic[2]) > config.quadratic_improvement_px
                             or (np.max(linear[2][linear[1]]) > config.inlier_threshold_px * .75
                                 and np.median(quadratic[2]) < np.median(linear[2]))):
            model, degree = quadratic, 2
    if model is None:
        return None
    coef, inliers, residual, condition = model
    robust_count = int(inliers.sum())
    # Round raster/paint caps produce row centroids outside the centre-curve's
    # supported longitudinal domain. Trim endpoint support and refit, instead of
    # treating the cap tip as an extrapolated curve observation.
    accepted_v = v[inliers]
    inliers = inliers & (v >= accepted_v.min() + config.fit_endpoint_margin_px)
    inliers &= v <= accepted_v.max() - config.fit_endpoint_margin_px
    if inliers.sum() < config.min_points:
        return None
    design = np.vander(t, degree + 1)
    coef = np.linalg.lstsq(design[inliers], u[inliers], rcond=None)[0]
    residual = np.abs(design @ coef - u)
    condition = float(np.linalg.cond(design[inliers]))
    count = int(inliers.sum())
    outlier_fraction = 1 - robust_count / len(p)
    if count < config.min_points or outlier_fraction > config.max_outlier_fraction:
        return None
    vi = v[inliers]
    span = float(np.ptp(vi))
    coverage = min(1.0, len(np.unique(vi)) * config.row_step / image_height)
    observed_coverage = min(1.0, robust_count * config.row_step / image_height)
    rms = float(np.sqrt(np.mean(residual[inliers] ** 2)))
    intervals, gaps = support_intervals(vi, config.row_step)
    max_gap = max((b - a for a, b in gaps), default=0.0)
    if span < config.min_span_px or observed_coverage < config.min_coverage or rms > config.max_residual_px or max_gap > config.max_gap_px:
        return None
    normalized = np.poly1d(coef)
    pixel = normalized(np.poly1d([1 / scale, -origin / scale]))
    abc = np.pad(np.asarray(pixel.c, float), (3 - len(pixel.c), 0))
    poly = Polynomial(tuple(map(float, abc)), float(vi.min()), float(vi.max()))
    test_v = np.linspace(poly.v_min, poly.v_max, 64)
    slope = 2 * abc[0] * test_v + abc[1]
    # Include zero derivative, where quadratic curvature reaches its maximum.
    min_abs_slope = float(np.min(np.abs(slope)))
    if abc[0] != 0 and poly.v_min <= -abc[1] / (2 * abc[0]) <= poly.v_max:
        min_abs_slope = 0.0
    curvature = float(abs(2 * abc[0]) / (1 + min_abs_slope ** 2) ** 1.5)
    if np.max(np.abs(slope)) > config.max_abs_du_dv or curvature > config.max_curvature_px_inv:
        return None
    far = float(min(1.0, np.count_nonzero(vi < image_height / 2) * config.row_step / (image_height / 2)))
    near = float(min(1.0, np.count_nonzero(vi >= image_height / 2) * config.row_step / (image_height / 2)))
    quality = max(0.0, 1 - rms / config.max_residual_px)
    # Evidence density is conditional on the accepted fit domain. A side-exiting
    # marking can be well observed on a short domain; full-frame coverage remains
    # separately reported and still enforces the independent support floor.
    density = min(1.0, count * config.row_step / (span + config.row_step))
    confidence = float((.55 * density + .25 * min(1, span / image_height) + .20 * quality) * (1 - outlier_fraction))
    reasons = []
    if gaps:
        reasons.append("unsupported_gaps")
    if coverage < .7:
        reasons.append("partial_coverage")
    if outlier_fraction > 0:
        reasons.append("outliers_removed")
    excluded = support_intervals(v[~inliers], config.row_step)[0] if np.any(~inliers) else ()
    if any(hi - lo >= config.max_unmodeled_run_px for lo, hi in excluded):
        reasons.append("model_support_truncated")
    diagnostics = FitDiagnostics(degree, len(p), count, rms, float(np.percentile(residual[inliers], 95)),
                                 coverage, span, near, far, max_gap, curvature, condition,
                                 near_confidence=_section_score(residual[inliers][vi >= image_height / 2], near, config),
                                 far_confidence=_section_score(residual[inliers][vi < image_height / 2], far, config),
                                 input_span_px=float(np.ptp(v)), retained_fraction=float(count / len(p)),
                                 endpoint_trimmed_points=robust_count - count,
                                 observed_coverage_before_endpoint_trim=observed_coverage,
                                 signed_curvature_reference_px_inv=float(-2 * abc[0] /
                                     (1 + (2 * abc[0] * (poly.v_min + poly.v_max) / 2 + abc[1]) ** 2) ** 1.5))
    return Boundary(candidate_id, poly, True, confidence, tuple(reasons), intervals, gaps, diagnostics,
                    excluded_observation_intervals=excluded)


def _section_score(residual: np.ndarray, coverage: float, config: LaneConfig) -> float:
    if len(residual) == 0:
        return 0.0
    rms = float(np.sqrt(np.mean(residual ** 2)))
    return float(coverage * max(0.0, 1 - rms / config.max_residual_px))
