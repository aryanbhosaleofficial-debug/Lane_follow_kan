# M03 advanced lane detection

M03 consumes **M02 BEVFrame objects**, detects per-frame marking boundaries and
returns conservative lane observations. It implements no navigation, persistent
tracking, waypoint generation or vehicle control. NumPy and OpenCV are the only
external dependencies. The legacy raw-image detector and four-point IPM tools
remain separate and unchanged.

## Pipeline

1. Validate the BGR frame, grid, binary masks, geometry and profile identity.
2. Intersect `valid_mask` and `support_mask`, with an eroded safety margin.
3. Extract white/yellow HSV evidence. Optional local contrast helps dim paint;
   optional CLAHE, blur and opening are independently configured. Opening only
   removes evidence. Closing is deliberately omitted: gaps must remain visible.
4. Run Canny/Hough on evidence. Retain vertical segments, reject transverse/short
   strokes, suppress overlapping votes. Hough supports the confidence of curve
   candidates; curves do not require Hough success.
5. Gather marking-run centres at sampled rows. Associate bottom to top using
   bounded robust local predictions and one-to-one assignments, retaining multiple
   chains. Runs wider than the marking-width limit are not lane evidence.
6. Fit normalized linear/quadratic models with deterministic robust sampling and
   inlier refitting. A clean-fit fast path and batched small solves reduce CPU
   cost. Prefer a linear fit when quadratic improvement is insufficient. Reject
   insufficient span/coverage, excessive gaps/residuals, slope and curvature.
7. Check adjacent-pair ordering, analytic ordering extrema, normal-distance width consistency,
   convergence/intersections and supported curve/centreline pixels. Preserve
   competing pairs; do not select an intended lane by image half or vehicle position.
8. Emit provenance, evidence diagnostics, confidence, validity and stage timings.

The polynomial is **`u(v) = a*v² + b*v + c`** in BEV pixels. `v_min..v_max` is the
accepted longitudinal domain. There is **zero endpoint extrapolation**. The
polynomial also describes internal gaps mathematically, but each gap is listed in
`unsupported_intervals`. `observed_intervals` describe associated sampled rows,
not a dense claim that every pixel between row centres was painted. Debug
`accepted_mask` is always a subset of actual thresholded candidate pixels.

## API and M01/M02 integration

```python
from camera_input import CameraConfig, CameraManager
from camera_calibration import CalibrationProfile, BEVProcessor, BEVWorker
from lane_detection.advanced import LaneConfig, LaneDetector

# Supply your own camera profile and measured grid-specific screening bounds.
profile = CalibrationProfile.load("vehicle_metric.json")
detector = LaneDetector(LaneConfig())
width, height = profile.image_size
with CameraManager(CameraConfig(source=0, width=width, height=height)) as camera:
    with BEVWorker(BEVProcessor(profile), camera) as worker:
        sequence = 0
        while True:
            frame = worker.wait_for_bev(sequence, timeout=1.0)
            sequence = frame.bev_sequence
            observation = detector.process(frame)  # no camera I/O or GUI here
            # A future consumer must inspect validity AND coordinate/trust fields.
```

M01 timestamps and `(source_session_id, source_frame_id)` are preserved. The
detector holds one frame/result; processing the exact latest object again returns
the same observation. Different objects claiming that identity, and backward IDs
within a session, are rejected. A new session is independent. No previous curve
is reused when current-frame evidence disappears. Calls are serialized with a
lock. M02's latest-only worker keeps acquisition independent of M03; slow consumers
can skip frames. This is bounded latency delivery, not guaranteed video decoding
of every frame. CLI JSONL and run summaries report consumer skips and end reason.
M03 does not provide a separate tracking or asynchronous prediction worker.

Freshness is checked on every call, including cached repeats. The default
`max_frame_age_s=0.5` uses acquisition monotonic time and raises M02's
`StaleFrameError`. Invalid/future timestamps are refused. Configure
`max_frame_age_s=None` explicitly for offline replay. The CLI selects offline
semantics for images/recordings and retains checks for cameras/streams.
`processing_frame_age_s` describes the original processing instant, including on
cached results; consumers must recompute current age from acquisition time.

## Validity, confidence and calibration

`validity == "valid"` requires exactly one compatible, independently observed
pair, sufficient boundary evidence, no detected branch/capacity ambiguity and a
pair confidence at least `min_pair_confidence`. With ambiguous or missing evidence,
output is `uncertain`; no supported boundaries produces `invalid`. Ambiguous and
low-score observed pairs have **no selected centreline**. `compatible_pairs` are
hypotheses for inspection, not instructions to select a route.

An explicitly configured width prior plus `single_boundary_role` may produce an
inferred pair; it **always remains uncertain**, with `inferred=True`, a lower score,
an unobserved boundary and missing-boundary metadata. Its centreline is an uncertain
estimate and must not be treated as a valid observation. Inference uses a normal
offset and refuses folded offsets or inaccurate polynomial approximations.

Scores are engineering evidence scores, **not calibrated probabilities**. Boundary
score uses 55% evidence density within the accepted domain, 25% full-frame
longitudinal span and 20% residual quality, penalized
by rejected-point fraction. Hough support contributes a factor in 0.95..1.0.
Pixel evidence confidence is independent of metric trust. Pair score uses the weaker boundary
and a width-variation penalty. Inference applies a 0.45 factor. Unselected uncertain
observations use a 0.35 factor. These are documented screening heuristics to tune
against labelled track data, not a statistical reliability claim. Near/far coverage,
RMS/p95 residual, inlier counts, gaps, curvature and normalized conditioning remain
available separately in diagnostics. Near/far confidence fields are local evidence
scores: half-frame row coverage times residual quality for that half. They do not
incorporate physical calibration trust; inspect `metric_validated` separately.

Output curves always use pixels. **Ground samples and metric widths are absent
unless `frame.validated_geometry()` succeeds**. A status string alone cannot grant
trust. Metre width/curvature constraints and metre inference priors also require
that gate; otherwise pair validity is refused, with pixel candidates retained.
Ground sample axes use M02 conversions: X forward metres, Y left metres; BEV u
right, v down. Forward is upward. Curvature is `|u''|/(1+u'^2)^1.5` in inverse pixels;
only validated geometry permits inverse-metre screening (`curvature_px / mpp`).
No unverified metric number is exported. Neither M02 mask detects object occlusion,
raised objects, road semantics or free space.

## Configuration

`LaneConfig` is frozen and validates types, ranges and related bounds. See
[config.py](config.py) for every parameter. Important groups are:

| Parameters | Meaning |
|---|---|
| `preprocessing`, `white_*`, `yellow_*` | Fixed HSV evidence or selectable local-contrast white evidence |
| `blur_size`, `opening_size`, `clahe` | Optional image operations; sizes of 1 disable blur/opening |
| `roi_margin_px` | Erode visibility/support intersection to suppress border evidence |
| `canny_*`, `hough_*` | Supporting edge/segment extraction |
| `row_step`, `max_marking_width_px` | Row sampling and acceptable paint-run width |
| `association_margin_px`, `max_gap_px` | Bounded lateral association and internal evidence gap |
| `min_points`, `min_span_px`, `min_coverage` | Independent observed support floor |
| `max_residual_px`, `inlier_threshold_px`, `max_outlier_fraction` | Robust fit acceptance |
| `max_abs_du_dv`, `max_curvature_px_inv` | BEV orientation/curve screening |
| `min_lane_width_px`, `max_lane_width_px`, `max_width_variation` | Lateral separation screening, not measured physical track dimensions |
| `lane_width_m`, `max_curvature_m_inv` | Optional trusted metric constraints |
| `nominal_lane_width_px` or `nominal_lane_width_m`, `single_boundary_role` | Explicit optional inference assumptions |
| `max_tracks`, `max_row_runs` | Work caps; exceeding them forces uncertainty |

Default pixel bounds are broad screening values for small BEV grids. Tune them
for your calibrated output resolution, actual paint thickness, measured track
widths and intended forward extent. There is **no default nominal physical width**.
Widths use directed normal intersections in both directions. Ambiguous or absent
supported intersections refuse a pair. Correspondence midpoints define
`centreline_points_px`; the centreline polynomial must approximate them within
`centreline_fit_tolerance_px` (default 1 px). Widths are sampled on fitted geometry.
Signed reference curvature is positive for a vehicle-left turn as ground X
increases. Absolute curvature is exact for the fitted quadratic, not a claim that
the real road is quadratic.
Models with overhangs/multiple u values at the same v cannot be represented by one
quadratic; this detector conservatively loses support or reports ambiguity.

CLI configuration is a JSON object of `LaneConfig` overrides. For example, the
synthetic 320x240 road with independently specified 100-pixel lane separation can
use `{"min_lane_width_px": 85, "max_lane_width_px": 115}`. This example is not a
measurement of the competition track. Threshold defaults do not scale themselves
silently when changing grid resolution.

For equivalent geometry on another BEV scale, use
`LaneConfig.for_bev(bev, lane_width_m=(measured_min, measured_max))`. Supply your own
width configuration. Algorithm lengths scale from a reference nominal grid
(default 0.004 m/px); counts/work limits remain separate. Unverified scale produces
nominal pixel bounds plus `physical_configuration_unverified`.
`require_validated_metric=True` refuses pairs until M02 grants metric trust.
Configuration is bound to that m/px; rebuild it when the scale changes. The factory
does not grant trust.

`max_tracks`, `max_row_runs`, `max_association_comparisons`, `max_fit_candidates`
bound work. Exhaustion stops fitting/pairing and returns uncertain with
`processing_budget_exceeded`, never a partial selected centreline. These are
operation limits, not a guaranteed wall-clock deadline. Hough is optional
(`use_hough=False`) and capped by `max_hough_segments`.

Local contrast honors `white_min_value`; lower it explicitly for dim paint (the
shadow demo uses 90). It no longer borrows the yellow brightness threshold.
Default yellow bounds exclude the tested orange and muted-tan swatches; color
alone cannot distinguish every material. `evidence_fraction` and
`saturated_marking_evidence` diagnose overly broad masks; configure
`max_evidence_fraction` for the refusal threshold.

## Pair observability and vehicle reference

`observed_fraction` counts observed endpoints divided by twice the number of
uniform centre-v bins (`support_samples`). Endpoint rows are interpolated from
normal correspondences, rather than assumed equal. `shared_observed_fraction`
requires both endpoints; `shared_observed_span_px` sums bin widths satisfying that
condition. `inferred_fraction` counts endpoints on an inferred boundary.
`unsupported_intervals` includes bins where either endpoint lacks observed paint.
All denominators use the accepted centreline v-domain. These are sampled evidence
diagnostics, not dense semantic labels. Sparse dashes can remain geometrically
valid with lower evidence fractions and confidence.

A valid geometric pair is not automatically an ego lane. Configure
`vehicle_reference_bev_px=(u,v)`, or explicitly declare
`ground_origin_is_vehicle=True` to use the actual BEV origin. Otherwise reference
status is unknown. No forward extrapolation is made outside supported domains.
`brackets_origin`, `lane_reference_valid` and `ego_lane_valid` remain separate from
lane geometry validity. `ego_offset_px` is lateral, positive vehicle-left of the
centre at the reference row. `ego_offset_m` has the same sign and requires trusted
scale. `BEVMetadata` carries the grid and documented origin; its m/px is nominal
metadata, not evidence that calibration is physically verified.

Coherent evidence rejected by a global fit is exposed in
`excluded_observation_intervals`. Runs exceeding `max_unmodeled_run_px` mark
`model_support_truncated` and prevent a valid selected centreline. The M02
straight-to-arc reference exercises this explicit unsupported-model policy.

`fit_endpoint_margin_px` excludes round paint/stroke tips from the centre-curve
domain and refits without them. Diagnostics distinguish final fit inliers from
`endpoint_trimmed_points`. The minimum observed-row floor is applied before this
conservative endpoint margin; final-domain coverage is separately reported. A
smaller median residual alone cannot justify a linear model whose endpoint error
exceeds the configured inlier screening scale.

## Reproducible commands

Run from repository root with the existing `requirements.txt` installed:

```powershell
python -m unittest discover -s lane_detection/advanced -t . -v
python -m unittest discover -v
python -m unittest camera_calibration.video_asset_tests -v
python -m lane_detection.advanced.evaluation --output outputs/m03/synthetic
python -m lane_detection.advanced.benchmark --frames 200 --warmup 20 --threads 1 --output outputs/m03/benchmark.json
python -m lane_detection.advanced --source videos/test.mp4 --profile calibration/test_video_metric_profile.json --headless --output outputs/m03/video_full
```

The bundled video profile has **synthetic, unverified geometry**. The video command
is an integration demonstration, not measured lane-width or track accuracy evidence.
Use `--limit 12` for a partial smoke run. `run_summary.json` distinguishes EOF,
limit, quit and errors, and includes profile origin and frame skips. JSONL preserves
the original IDs; it does not renumber skipped frames. Sampled overlays and candidate,
accepted and rejected PNGs use `--save-every` (default 30). `--headless` makes no GUI
calls. Omit it for windows. Green is observed fit, orange dashes are gaps/inference,
cyan is the selected centreline; masks separately show evidence. Drawing always
copies the shared image. Diagnostic time is included when debug is requested.

For your own image, video, camera (`--source 0`) or stream, replace `--source` and
`--profile` with compatible inputs. Images are processed through M02; **raw-image
pixels are never relabelled as BEV**. Profile source bindings and exact acquisition
resolution remain enforced. Legacy `calibration/ipm_calibration.json` cannot be
used as an M02 profile. The old `python lane_detection/lane_detection.py ...`
remains the separately documented raw-image compatibility path.

`--validation-measurements path.json` re-runs the existing M02 validator. Required
fields: `profile_fingerprint`, `tolerance_m`, `provenance` (operator, method,
reference, independent_from_fit=true), and `distances` containing M02
DistanceMeasurement fields. The fingerprint must match and all M02 evidence/trust
requirements apply. A saved report summary cannot grant trust and is not accepted
in place of independent attested measurements.

## Validation and limits

See [M03_CORRECTIVE_REPORT.md](../M03_CORRECTIVE_REPORT.md) for reviewed repairs.
Historical initial evidence is in [M03_VALIDATION.md](../M03_VALIDATION.md), [M03_BENCHMARK.json](../M03_BENCHMARK.json)
and [M03_SYNTHETIC_EVALUATION.json](../M03_SYNTHETIC_EVALUATION.json).
Synthetic pass results exercise software geometry; they do not establish real-track
reliability. Strong reflections, unusual paint colors, severe shadows, occluders,
large gaps, very tight or sideways turns and complex topology remain challenges.
Conservative gates may reject usable lanes; ambiguous pair output intentionally
does not choose a driving lane. Raspberry Pi latency, camera mounting, physical
metric calibration, thermal performance and labelled real-track accuracy remain
unvalidated. There is no ROS, IMU compensation, route/roundabout selection or control.
