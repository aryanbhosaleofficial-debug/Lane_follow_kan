"""Non-destructive clean-HEAD plus overlay reconstruction smoke test."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

root=Path(__file__).resolve().parents[3]
work=root/'outputs/m03/final_correction'
target=work/'reconstructed_scoped'
assert not target.exists(), 'Refusing to overwrite an existing reconstruction'
target.mkdir()
assert target.resolve().is_relative_to(work.resolve())
with zipfile.ZipFile(work/'head_for_reconstruction.zip') as z:
    for name in z.namelist():
        assert (target/name).resolve().is_relative_to(target.resolve())
    z.extractall(target)
with zipfile.ZipFile(root/'lane_detection/M03_FINAL_REVIEW_BUNDLE.zip') as z:
    hashes=json.loads(z.read('manifest.json'))
    assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for name,digest in hashes.items())
    for name in hashes:
        if name.startswith('overlay/'):
            relative=name[len('overlay/'):]
        elif name.startswith('baseline/'):
            relative='outputs/m03/final_correction/'+name
        else:
            continue
        path=target/relative
        assert path.resolve().is_relative_to(target.resolve())
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(z.read(name))
log=root/'m03_final_reconstructed_scoped.log'
with log.open('w') as stream:
    result=subprocess.run([sys.executable,'-m','unittest','discover','-v'],cwd=target,
                          stdout=stream,stderr=subprocess.STDOUT)
text=log.read_text()
counts=re.findall(r'^Ran (\d+) tests in ([\d.]+)s$',text,re.M)
assert result.returncode==0 and re.search(r'^OK$',text,re.M)
assert int(counts[0][0])==440
report=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
            overlay_manifest_verified=True,baseline_below_outputs=True,
            reconstructed_directory=str(target.relative_to(root)),
            command='python -m unittest discover -v',passed=440,failed=0,skipped=0,
            seconds=float(counts[0][1]),log=log.name)
(work/'final_reconstruction.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
